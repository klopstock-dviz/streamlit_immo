import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt


#Encodage de la position
def positional_encoding(position_max, d_model):
    i = np.linspace(0, d_model-1, d_model)
    
    pos_enconding = np.zeros((position_max, d_model))
    
    for pos, row in enumerate(pos_enconding):
        pos_enconding[pos, ::2] = np.sin(pos/(10000 ** (i[::2]/d_model)))
        pos_enconding[pos, 1::2] = np.cos(pos/(10000 ** ((i[1::2]-1)/d_model))) 
    
    return tf.cast(pos_enconding.reshape(1, position_max, d_model), dtype = tf.float32)


#reseau feed_forward
def feed_forward_network(d_model, dff):
    model = tf.keras.models.Sequential()
    model.add(tf.keras.layers.Dense(dff, activation='relu'))
    model.add(tf.keras.layers.Dense(d_model))

    return model


#Produit scalaire d'attention
def scaled_dot_product_attention(q, k, v, mask):
    """Calculate the attention weights.
    q, k, v must have matching leading dimensions.
    k, v must have matching penultimate dimension, i.e.: seq_len_k = seq_len_v.
    The mask has different shapes depending on its type(padding or look ahead) 
    but it must be broadcastable for addition.

    Args:
    q: query shape == (..., seq_len_q, depth)
    k: key shape == (..., seq_len_k, depth)
    v: value shape == (..., seq_len_v, depth_v)
    mask: Float tensor with shape broadcastable 
          to (..., seq_len_q, seq_len_k). Defaults to None.

    Returns:
    output, attention_weights
    """
    try:
        matmul_qk = tf.matmul(q, k, transpose_b=True)  # (..., seq_len_q, seq_len_k)

        # scale matmul_qk
        dk = tf.cast(tf.shape(k)[-1], tf.float32)
        scaled_attention_logits = matmul_qk / tf.math.sqrt(dk)
        #print(scaled_attention_logits.shape)

        # add the mask to the scaled tensor.
        if mask is not None:
            scaled_attention_logits += (mask * -1e9)  
            # The mask is multiplied by -infinity so the resulting softmax of masked attention logits is 0

        # softmax is normalized on the last axis (seq_len_k) so that the scores
        # add up to 1.
        attention_weights = tf.nn.softmax(scaled_attention_logits, axis=-1)  # (..., seq_len_q, seq_len_k)

        attention_vectors = tf.matmul(attention_weights, v)  # (..., seq_len_q, depth_v)

        return attention_vectors, attention_weights
    except Exception as e:
        print(e)
        return None


#Couche d'attention multi-têtes
class MultiHeadAttention(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads):
        super(MultiHeadAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model

        assert d_model % self.num_heads == 0

        self.depth = d_model // self.num_heads

        self.wq = tf.keras.layers.Dense(d_model)
        self.wk = tf.keras.layers.Dense(d_model)
        self.wv = tf.keras.layers.Dense(d_model)

        self.dense = tf.keras.layers.Dense(d_model)

    def split_heads(self, x, batch_size):
        """Split the last dimension into (num_heads, depth).
        Transpose the result such that the shape is (batch_size, num_heads, seq_len, depth)
        """

        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))

        output = tf.transpose(x, perm=[0, 2, 1, 3])        
        return output

    def call(self, v, k, q, mask):
        batch_size = tf.shape(q)[0]
        
        #1. Embedding :
        q = self.wq(q)  # (batch_size, seq_len, d_model)
        k = self.wk(k)  # (batch_size, seq_len, d_model)
        v = self.wv(v)  # (batch_size, seq_len, d_model)
        
        #2. séparation des têtes
        q = self.split_heads(q, batch_size)  # (batch_size, num_heads, seq_len_q, depth)
        k = self.split_heads(k, batch_size)  # (batch_size, num_heads, seq_len_k, depth)
        v = self.split_heads(v, batch_size)  # (batch_size, num_heads, seq_len_v, depth)
        
        #3. Produit scalaire d'attention
        # scaled_attention.shape == (batch_size, num_heads, seq_len_q, depth)
        # attention_weights.shape == (batch_size, num_heads, seq_len_q, seq_len_k)
        scaled_attention, attention_weights = scaled_dot_product_attention(
            q, k, v, mask)
        
        #4. Reconcaténation
        scaled_attention = tf.transpose(scaled_attention, perm=[0, 2, 1, 3])  # (batch_size, seq_len_q, num_heads, depth)

        concat_attention = tf.reshape(scaled_attention, 
                                      (batch_size, -1, self.d_model))  # (batch_size, seq_len_q, d_model)

        output = self.dense(concat_attention)  # (batch_size, seq_len_q, d_model)

        return output, attention_weights
    
#Couche d'encodage
class EncoderLayer(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, dff, rate=0.1):
        super(EncoderLayer, self).__init__()
        self.mha = MultiHeadAttention(d_model, num_heads)
        self.ffn = tf.keras.models.Sequential()
        self.ffn.add(tf.keras.layers.Dense(dff, activation='relu'))
        self.ffn.add(tf.keras.layers.Dense(d_model))
        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = tf.keras.layers.Dropout(rate)
        self.dropout2 = tf.keras.layers.Dropout(rate)

    def call(self, x, training=False, mask=None):
        A, _ = self.mha(x, x, x, mask)
        A = self.dropout1(A, training=training)
        x = A + x
        x = self.layernorm1(x)
        O = self.ffn(x)
        O = self.dropout2(O)
        x = O + x
        output = self.layernorm2(x)
        return output


#Couche de décodage
class DecoderLayer(tf.keras.layers.Layer):
    def __init__(self, d_model, num_heads, dff, rate=0.1):
        """        
        d_model : Dimensionality of the embedding layer's output.
        
        num_heads : Number of attention heads in the Multi-Head Attention layers.
        
        dff : Number of neurons in the first layer of the Feed Forward Network in the Decoding layers.
        
        rate : Dropout rate in the Decoding layers.      
        """
        super(DecoderLayer, self).__init__()

        self.mha1 = MultiHeadAttention(d_model, num_heads)
        self.mha2 = MultiHeadAttention(d_model, num_heads)

        self.ffn = tf.keras.models.Sequential()
        self.ffn.add(tf.keras.layers.Dense(dff, activation='relu'))
        self.ffn.add(tf.keras.layers.Dense(d_model))

        self.layernorm1 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layernorm3 = tf.keras.layers.LayerNormalization(epsilon=1e-6)

        self.dropout1 = tf.keras.layers.Dropout(rate)
        self.dropout2 = tf.keras.layers.Dropout(rate)
        self.dropout3 = tf.keras.layers.Dropout(rate)
    
    
    def call(self, x, enc_output, training=False, look_ahead_mask=None, padding_mask=None):
    
        """
        x : Input Tensor of the partially translated sentence.
        
        enc_output : Output Tensor of the Encoder.
        
        training : Whether the model is training or not so that Dropout is only applied during training.
        
        look_ahead_mask : Tensor for masking tokens that have not been translated yet.
        
        padding_mask : Tensor masking padding tokens of the Decoder's output.      
        """

        A1, _ = self.mha1(x, x, x, look_ahead_mask)
        A1 = self.dropout1(A1, training=training)
        x = A1 + x
        x = self.layernorm1(x)

        A2, _ = self.mha2(enc_output, enc_output, x, padding_mask)
        A2 = self.dropout2(A2, training=training)
        x = A2 + x
        x = self.layernorm2(x)

        O = self.ffn(x)
        O = self.dropout3(O)
        x = O + x
        output = self.layernorm3(x)

        return output
    
     
class Encoder(tf.keras.layers.Layer):
    def __init__(self, num_layers, d_model, num_heads, dff, input_vocab_size,
                 maximum_position_encoding, rate=0.1):
        super(Encoder, self).__init__()
        self.d_model = d_model
        self.num_layers = num_layers
        self.embedding = tf.keras.layers.Embedding(input_vocab_size, d_model)
        self.pos_encoding = positional_encoding(maximum_position_encoding, self.d_model)
        self.enc_layers = [EncoderLayer(d_model, num_heads, dff, rate) for _ in range(num_layers)]
        self.dropout = tf.keras.layers.Dropout(rate)

    def call(self, x, training=False, mask=None):
        seq_len = tf.shape(x)[1]
        x = self.embedding(x)
        x += self.pos_encoding[:, :seq_len, :]
        x = self.dropout(x, training=training)
        for i in range(self.num_layers):
            x = self.enc_layers[i](x, training=training, mask=mask)
        return x


class Decoder(tf.keras.layers.Layer):
    def __init__(self, num_layers, d_model, num_heads, dff, target_vocab_size,
               maximum_position_encoding, rate=0.1):
        """
        num_layers : Number of Decoding layers in the Decoder.
        
        d_model : Dimensionality of the embedding layer's output.
        
        num_heads : Number of attention heads in the Multi-Head Attention layers.
        
        dff : Number of neurons in the first layer of the Feed Forward Network in the Decoding layers.
        
        target_vocab_size : Size of the vocabulary the Decoder's embedding layer should train on.
        
        maximum_position_encoding : Maximum number of tokens in a sequence.
        
        rate : Dropout rate in the Decoding layers.      
        """
        
        super(Decoder, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers

        self.embedding = tf.keras.layers.Embedding(target_vocab_size, d_model)
        self.pos_encoding = positional_encoding(maximum_position_encoding, d_model)

        self.dec_layers = [DecoderLayer(d_model, num_heads, dff, rate) 
                           for _ in range(num_layers)]
        self.dropout = tf.keras.layers.Dropout(rate)
    
    def call(self, x, enc_output, training=False, look_ahead_mask=None, padding_mask=None):
        
        """
        x : Input Tensor of the partially translated sentence.
        
        enc_output : Output Tensor of the Encoder.
        
        training : Whether the model is training or not so that Dropout is only applied during training.
        
        look_ahead_mask : Tensor for masking tokens that have not been translated yet.
        
        padding_mask : Tensor masking padding tokens of the Decoder's input.      
        """
        
        # Generate Embedding
        x = self.embedding(x)

        # Add Positional Encoding
        seq_len = tf.shape(x)[1]
        x += self.pos_encoding[:, :seq_len, :]

        # Apply Dropout
        x = self.dropout(x, training=training)

        # Apply Decoding Layers
        for i in range(self.num_layers):
            x = self.dec_layers[i](x, enc_output= enc_output, training=training, look_ahead_mask=look_ahead_mask, padding_mask=padding_mask)

        return x 

class Transformer(tf.keras.Model):
    def __init__(self, num_layers, d_model, num_heads, dff, input_vocab_size, 
               target_vocab_size, pe_input, pe_target, rate=0.1):
        """
        num_layers : Number of Encoding/Decoding layers in the Encoder/Decoder.
        d_model    : Dimensionality of the embedding layers' output.
        num_heads  : Number of attention heads in the Multi-Head Attention layers.
        dff        : Number of neurons in the first layer of the Feed Forward Network in the Encoding/Decoding layers.
        rate       : Dropout rate in the Encoding/Decoding layers.    
        
        input_vocab_size  : Size of the vocabulary the Encoder's embedding layer should train on.
        target_vocab_size : Size of the vocabulary the Encoder's embedding layer should train on.
        
        
        pe_input  : Maximum number of tokens in the input sequence of the Encoder.
        pe_target : Maximum number of tokens in the input sequence of the Decoder.
        """       
        super(Transformer, self).__init__()

        self.encoder = Encoder(num_layers, d_model, num_heads, dff, 
                               input_vocab_size, pe_input, rate)

        self.decoder = Decoder(num_layers, d_model, num_heads, dff, 
                               target_vocab_size, pe_target, rate)

        self.final_layer = tf.keras.layers.Dense(target_vocab_size, activation = 'softmax')
    
    def call(self, encoder_input, decoder_input ,training=False, enc_padding_mask=None, 
           look_ahead_mask=None, dec_padding_mask=None):
        """
        encoder_input : Input Tensor of the original sentence to be given to the Encoder.
        decoder_input : Input Tensor of the partially translated sentence to be given to the Decoder.
        
        training : Whether the model is training or not so that Dropout is only applied during training.
        
        enc_padding_mask : Tensor masking padding tokens of the Encoder's input.
        look_ahead_mask  : Tensor for masking tokens that have not been translated yet.
        dec_padding_mask : Tensor masking padding tokens of the Decoder's input.      
        """

        # Get Encoder Output
        enc_output=self.encoder(encoder_input, training=training, mask=enc_padding_mask)
        
        
        # Get Decoder Output
        dec_output=self.decoder(encoder_input,
                                enc_output=enc_output, 
                                training=training,
                                look_ahead_mask=look_ahead_mask, 
                                padding_mask=dec_padding_mask)


        # Perform Classification
        final_output = self.final_layer(dec_output)

        return final_output