from bqplot import LinearScale, Scatter, Axis, Figure, Lines, Label
import ipywidgets as widgets
from IPython.display import display
import numpy as np

import asyncio
from time import time
import markdown

    # Throttler
def attention_widget():
    if True:
        class Timer:
            def __init__(self, timeout, callback):
                self._timeout = timeout
                self._callback = callback
                self._task = asyncio.ensure_future(self._job())

            async def _job(self):
                await asyncio.sleep(self._timeout)
                self._callback()

            def cancel(self):
                self._task.cancel()


        def throttle(wait):
            """ Decorator that prevents a function from being called
                more than once every wait period. """
            def decorator(fn):
                time_of_last_call = 0
                scheduled = False
                new_args, new_kwargs = None, None

                def throttled(*args, **kwargs):
                    nonlocal new_args, new_kwargs, time_of_last_call, scheduled

                    def call_it():
                        nonlocal new_args, new_kwargs, time_of_last_call, scheduled
                        time_of_last_call = time()
                        fn(*new_args, **new_kwargs)
                        scheduled = False
                    time_since_last_call = time() - time_of_last_call
                    new_args = args
                    new_kwargs = kwargs
                    if not scheduled:
                        new_wait = max(0, wait - time_since_last_call)
                        Timer(new_wait, call_it)
                        scheduled = True
                return throttled
            return decorator


    ######## Scales #################################################
    if True:
        figure1_sc_x = LinearScale(min=-5, max=5)
        figure1_sc_y = LinearScale(min=-5, max=5)
        figure1_sc_rotation = LinearScale(min=0, max=180)
        figure1_sc_size = LinearScale(min=0, max=30)

        figure2_sc_x = LinearScale(min=-5, max=5)
        figure2_sc_y = LinearScale(min=-5, max=5)
        figure2_sc_rotation = LinearScale(min=0, max=180)
        figure2_sc_size = LinearScale(min=0, max=30)

    ######## Query vector plot ######################################

    if True: 
        figure1_query_scatter = Scatter(
            scales={'x': figure1_sc_x,
                    'y': figure1_sc_y,
                    'size': figure1_sc_size,
                    'rotation': figure1_sc_rotation},
            x=[0, 0],
            y=[0, 1],
            names = ["", "Query Vector"],
            display_names = True,
            size=np.array([0, 100]),
            enable_move=False)

        figure1_query_lines = Lines(
            scales={'x': figure1_sc_x,
                    'y': figure1_sc_y},
            x=[0, 0],
            y=[0, 1])

        widgets.jslink((figure1_query_scatter, 'x'), (figure1_query_lines, 'x'))
        widgets.jslink((figure1_query_scatter, 'y'), (figure1_query_lines, 'y'))

    ######## Keys vector plot ########################################
    if True:
        # Keys vectors values

        figure1_keys_x = np.array([0., 1.15, 0., -4.2, 0.,  -3.2,  0., 1.5])

        figure1_keys_y = np.array([0., 2.13,  0., 3.18, 0., -2.52, 0., -0.25])

        figure1_keys_sizes = np.array([0., 10.,  0., 10.,  0., 10.,  0., 10.])

        # lines 
        figure1_keys_lines = Lines(
            scales={'x': figure1_sc_x,
                    'y': figure1_sc_y},
            x=figure1_keys_x,
            y=figure1_keys_y,
            colors=['green'])

        # scatter
        figure1_keys_scatter = Scatter(
            scales={'x': figure1_sc_x,
                    'y': figure1_sc_y,
                    'size': figure1_sc_size,
                    'rotation': figure1_sc_rotation},
            names = ["", "Key Vector 1",
                     "", "Key Vector 2",
                     "", "Key Vector 3",
                     "", "Key Vector 4"],
            display_names = True,
            x=figure1_keys_x,
            y=figure1_keys_y,
            size=figure1_keys_sizes,
            colors=['green']
        )

    ######## Attention Vector Plot ###################################
    if True:
        figure1_attention_lines = Lines(
            scales={'x': figure1_sc_x,
                    'y': figure1_sc_y},
            x=[0, 0],
            y=[0, 1],
            colors=['red'])

        figure1_attention_scatter = Scatter(
            scales={'x': figure1_sc_x,
                    'y': figure1_sc_y,
                    'size': figure1_sc_size,
                    'rotation': figure1_sc_rotation},
            names = ["", "Attention Vector"],
            display_names = True,
            x=[0, 0],
            y=[0, 1],
            size=[0, 20],
            colors=['red']
        )

        widgets.jslink((figure1_attention_scatter, 'x'),
                       (figure1_attention_lines, 'x'))
        widgets.jslink((figure1_attention_scatter, 'y'),
                       (figure1_attention_lines, 'y'))

    ######## Attention vector label ##################################
    if True:
        figure2_att_weights_label = Label(scales={'x': figure2_sc_x,
                                                  'y': figure2_sc_y},
                                          x=[-1],
                                          y=[1],
                                          text=["Attention Weights"],
                                          default_size=30,
                                          align='middle',
                                          colors=['#2F4F4F']
                                          )

        figure2_att_weights = Label(scales={'x': figure2_sc_x,
                                            'y': figure2_sc_y},
                                    x=[-1],
                                    y=[-0.5],
                                    text=["[{}, {}, {}, {}]".format(0, 0, 0, 0)],
                                    default_size=30,
                                    align='middle',
                                    colors=['#2F4F4F']
                                    )

    ######## Slider Widgets ##########################################
    if True:
        figure1_query_widget_x = widgets.FloatSlider(min=-5, max=5,
                                                     step=0.1, value=0,
                                                     description = markdown.markdown(r"$Q_x$"))
        figure1_query_widget_y = widgets.FloatSlider(min=-5, max=5, 
                                                     step=0.1, value=1,
                                                     description = markdown.markdown(r"$Q_y$"))

        figure1_display_names = widgets.Checkbox(value=True,
                                                 description='Display Names',
                                                 disabled=False)

        widgets.jslink((figure1_display_names, 'value'), (figure1_query_scatter, 'display_names'))
        widgets.jslink((figure1_display_names, 'value'), (figure1_keys_scatter, 'display_names'))
        widgets.jslink((figure1_display_names, 'value'), (figure1_attention_scatter, 'display_names'))


    ######## Callbacks ###############################################
    if True:
        @throttle(1/20)
        def figure1_attention_callback(change):
            x = figure1_query_widget_x.value
            y = figure1_query_widget_y.value

            figure1_query_scatter.x = [0, x]
            figure1_query_scatter.y = [0, y]

            keys_vectors = np.array([figure1_keys_x[1::2], figure1_keys_y[1::2]]).T
            query_vector = np.array([x, y])

            logits = keys_vectors.dot(query_vector)/np.sqrt(2)
            softmax = np.exp(logits)/np.sum(np.exp(logits))

            figure2_att_weights.text = [
                "[{}, {}, {}, {}]".format(*tuple(np.round(softmax, 3)))]

            attention_vector = (keys_vectors * softmax[:, np.newaxis]).sum(axis=0)

            figure1_attention_scatter.x = [0, attention_vector[0]]
            figure1_attention_scatter.y = [0, attention_vector[1]]


        figure1_query_widget_x.observe(figure1_attention_callback)
        figure1_query_widget_y.observe(figure1_attention_callback)

    ######## Axes #####################################################
    if True:
        figure1_ax_y = Axis(label='y', scale=figure1_sc_y,
                            orientation='vertical', side='left',
                            grid_lines='none', tick_values=None)
        figure1_ax_x = Axis(label='x', scale=figure1_sc_x, grid_lines='none')

        figure2_ax_y = Axis(label='y', scale=figure2_sc_y,
                            orientation='vertical', side='left',
                            grid_lines='none', tick_values=None,
                            visible=False)

        figure2_ax_x = Axis(label='x', scale=figure2_sc_x, grid_lines='none',
                            visible=False)

    ######## Figures ##################################################
    if True:
        # Figure 1

        figure1 = Figure(axes=[figure1_ax_x, figure1_ax_y],
                         marks=[
                         figure1_keys_lines, figure1_keys_scatter,
                         figure1_attention_scatter, figure1_attention_lines,
                         figure1_query_lines, figure1_query_scatter,
                         ],
                         animation_duration=0) 

        figure1.layout.height = '500px'
        figure1.layout.width = '500px'

        figure1.fig_margin = {"top": 0, "bottom": 40, "left": 40, "right": 0}

        # Figure 2

        figure2 = Figure(axes=[figure2_ax_x, figure2_ax_y],
                         marks=[
                             figure2_att_weights_label, figure2_att_weights
                         ],
                         animation_duration=0)
        figure2.layout.height = '500px'
        figure2.layout.width = '500px'

        figure2.fig_margin = {"top": 0, "bottom": 40, "left": 0, "right": 0}

        ######## Widget ###################################################

        figure1_box = widgets.HBox([figure1, figure2])
        figure1_sliders = widgets.VBox(
            [figure1_query_widget_x, figure1_query_widget_y])
        figure1_widgets = widgets.HBox([figure1_sliders, figure1_display_names])
        figure1_widget = widgets.VBox([figure1_box, figure1_widgets])

        figure1_widget.layout.justify_content = 'center'

    return(figure1_widget)

import numpy as np
from bqplot import (OrdinalScale, LinearScale, Bars, 
                    Figure, Axis, ColorScale, ColorAxis, CATEGORY10)
import bqplot.pyplot as plt
import ipywidgets as widgets
from IPython.display import display
import numpy as np

def position_encoding():
    size = 30

    posenc_x_data = range(size)
    posenc_y_data = np.ones(size) + 1

    posenc_x_ord = OrdinalScale()
    posenc_y_sc = LinearScale(min = 0, max = 2)
    posenc_col_sc = ColorScale(min = -1, max = 1, mid=0.0, colors = ['red', 'white','blue'])

    posenc_color_data =  np.random.rand(size) * 2 - 1

    posenc_bar = Bars(x=posenc_x_data, y=posenc_y_data, color=posenc_color_data, 
               scales={'x': posenc_x_ord,
                       'y': posenc_y_sc,
                       'color': posenc_col_sc},
               padding=0)#, color_mode='element')

    posenc_bar.base = 1.5


    posenc_ax_x = Axis(scale=posenc_x_ord,
                       label = 'Dimensions',
                       visible = True,
                       side = "top",
                       grid_lines = 'none')

    posenc_ax_y = Axis(scale=posenc_y_sc,
                       orientation='vertical',
                       tick_format='0.f',
                       visible = False)
    posenc_ax_c = ColorAxis(
        label='Color', 
        label_location='middle', 
        scale=posenc_col_sc, 
        orientation='vertical', 
        side='right',
        label_color = 'blue',
        offset = {'scale':posenc_x_ord,'value':10},
        tick_format = '1f'
    )

    posenc_ax_c = ColorAxis(
        label='Coordinate Value', 
        label_location='middle', 
        offset = {'value':10000},
        scale=posenc_col_sc, tick_format='0.00001f')

    posenc_fig = Figure(marks=[posenc_bar], axes=[posenc_ax_x, posenc_ax_y, posenc_ax_c])

    posenc_fig.layout.height = '250px'
    posenc_fig.layout.width = '900px'


    posenc_slider = widgets.IntSlider(min = 0, max = 100, value = 0,
                                     description = markdown.markdown(r"$pos$"))

    posenc_slider.style = {'description_width': '30px'}

    def posenc_callback(args):
        pos = posenc_slider.value

        colors = np.arange(1, size + 1, 1, dtype = float)
        colors[1::2] = np.sin(pos/(10000 ** (colors[1::2] / size)))
        colors[::2] = np.sin(pos/(10000 ** (colors[::2] / size)))

        posenc_bar.color = colors
        return

    posenc_callback("")

    posenc_slider.observe(posenc_callback)

    posenc_title = """<html>
                <head>
                    <style>
                        @font-face {
                            font-family: "Computer Modern";
                            src: url('http://mirrors.ctan.org/fonts/cm-unicode/fonts/otf/cmunss.otf');
                          }
                        .code-style {font-size: 25px;
                                    font-family : "Computer Modern";
                                    background-color: #11ffee00;
                                    line-height: 24px;
                                    color: black;}
                    </style>
                </head>
                <code class='code-style'>Positional Encoding Vector</code></html>"""

    posenc_title = widgets.HTML(value= posenc_title)

    posenc_widget = widgets.VBox([posenc_title, posenc_fig, posenc_slider])
    posenc_widget.layout.align_items = 'center'

    display(posenc_widget)
